package apiAssignment;

import java.io.IOException;

import org.testng.annotations.Test;

public class TestingGroup extends Testbase{
	
	String firstname="Sushanta";
	String middlename="Kumer";
	String lastname="Saha";
	String dob="14-12-1989";
	
//	@Test(description="to perform Methods of Swagger")
//	public void performTest()
//	{
//		//get User Details
//		this.get_GetUser("https://petstore.swagger.io/v2/user/user1", "message", 404);
//		
//		//creating user
//		this.post_CreateUser("{\r\n  \"id\": 0,\r\n  \"username\": \"ABC\",\r\n  \"firstName\": \"Abc\",\r\n  \"lastName\": \"Bcd\",\r\n  \"email\": \"abc@bbc.com\",\r\n  \"password\": \"abcbbc1\",\r\n  \"phone\": \"1234567890\",\r\n  \"userStatus\": 0\r\n}", "https://petstore.swagger.io/v2/user", "Content-Type","application/json", 200);
//		//Response resp=given().body("{\r\n  \"id\": 0,\r\n  \"username\": \"ABC\",\r\n  \"firstName\": \"Abc\",\r\n  \"lastName\": \"Bcd\",\r\n  \"email\": \"abc@bbc.com\",\r\n  \"password\": \"abcbbc1\",\r\n  \"phone\": \"1234567890\",\r\n  \"userStatus\": 0\r\n}").header("Content-Type","application/json").when().post("https://petstore.swagger.io/v2/user");
//	
//	}
	
//	@Test(description="to post with JSON file")
//	public void postJson() throws IOException
//	{
//		this.post_CreateUserWithJsonFile("https://petstore.swagger.io/v2/user", "postdata.json", "Content-Type","application/json", 200);
//		//FileInputStream file =new FileInputStream(new File(System.getProperty("user.dir")+"\\data\\postData.json"));
//		//Response resp=given().body(IOUtils.toString(file)).header("Content-Type","application/json").when().post("https://reqres.in/api/users");
//	}

	@Test(priority=3)
	public void createrecord() throws IOException
	{
		this.post_CreateUserwithoutjsonFile("{\r\n  \"id\": 1,\r\n  \"first_name\": \"sushanta\",\r\n  \"middle_name\": \" kumar\",\r\n  \"last_name\": \"saha\",\r\n  \"date_of_birth\": \"14-12-1989\"\r\n}", "http://thetestingworldapi.com/Help/api/studentsDetails", "Content-Type","application/json", 200);
		
	}
	
	@Test(priority=2)
	public void updaterecord() throws IOException
	{
		this.putmethodwithoutJson("{\r\n  \"id\": 1,\r\n  \"first_name\": \"sushanta11\",\r\n  \"middle_name\": \" kumar\",\r\n  \"last_name\": \"saha\",\r\n  \"date_of_birth\": \"14-12-1989\"\r\n}", "http://thetestingworldapi.com/Help/api/studentsDetails/id/1", "Content-Type","application/json", 200);
		
	}
	
	@Test(description="to perform GET modified User details")
	public void getUser()
	{
	//get User Details
	this.get_GetUser("http://thetestingworldapi.com/Help/api/studentsDetails/1", "message", 200);
	}
	
	@Test(priority=1)
	public void deleteJson() throws IOException
	{
		
         this.deletemethodvalue("http://thetestingworldapi.com/Help/api/studentsDetails/1",200);
	}

}
